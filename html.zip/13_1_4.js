function red(e) {
    e.target.style.backgroundColor = "red"
}

function blue(e) {
    e.target.style.backgroundColor = "blue"
}
